README_srcdos.txt for version 8.0 of Vim: Vi IMproved.

See "README.txt" for general information about Vim.
See "README_dos.txt" for installation instructions for MS-DOS and MS-Windows.
These files are in the runtime archive (vim80rt.zip).


The DOS source archive contains the files needed to compile Vim on MS-DOS or
MS-Windows.  It is packed for DOS systems, with CR-LF.  It also includes the
VisVim sources.

See "src/INSTALLpc.txt" for instructions on how to compile Vim on the PC.
