#!/usr/bin/python3

import sys
print(sys.version)
